CE 456 TCP Server/ Client Lab5
by Nick Baron 830278807

You need to have python3!

To run the server:

-cd into the directory that contains the server.py.
-run the py file using the python3 command: python3 server.py

To run the client: on a new machine

-cd into the directory containing the client.py file.
-run the client using the command: python3 client.py {server_ip_address} {file_to_be_sent}
